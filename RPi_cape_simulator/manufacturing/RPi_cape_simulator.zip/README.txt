Overall dimensions 104 x 96 mm (4.095" x 3.780")
Min. trace/spacing 0.18 mm (0.007")
Min. hole size 0.40 mm (0.016")

All copper layers positive
*-F_Cu.gbr: Top copper (signal)
*-B_Cu.gbr: Bottom copper (plane)
*-Edge_Cuts.gbr: Board outline
*-PTH.drl: Drill file (plated holes)
*-NPTH.drl: Drill file (non-plated holes)
