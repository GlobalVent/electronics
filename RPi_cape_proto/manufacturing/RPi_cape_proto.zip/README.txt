2 layers, 1.6 mm (0.062") thickness, LPI soldermask and silkscreen both sides
Outer layers 1 oz copper
RoHS HASL plating on pads
Overall dimensions 104 x 172 mm (4.095" x 6.772")
Min. trace/spacing 0.18 mm (0.007")
Min. hole size 0.26 mm (0.010")

All copper layers positive
*-F_Cu.gbr: Top copper (signal)
*-B_Cu.gbr: Bottom copper (plane)
*-F_Mask.gbr: Top soldermask
*-B_Mask.gbr: Bottom soldermask
*-F_SilkS.gbr: Top silkscreen
*-B_SilkS.gbr: Bottom silkscreen
*-Edge_Cuts.gbr: Board outline
*-PTH.drl: Drill file (plated holes)
*-NPTH.drl: Drill file (non-plated holes)
